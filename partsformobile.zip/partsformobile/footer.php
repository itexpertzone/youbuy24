<div class="clear"></div>
   <div class="footer">
   	  <div class="wrap">	
	     <div class="section group">

	     		<?php dynamic_sidebar( 'footer-one-widget-area' ); ?>

	     		<?php dynamic_sidebar( 'footer-two-widget-area' ); ?>

	     		<?php dynamic_sidebar( 'footer-three-widget-area' ); ?>

	     		<?php dynamic_sidebar( 'footer-four-widget-area' ); ?>
				
			</div>			
        </div>
        <div class="copy_right wrap">
				<img src="<?php echo get_template_directory_uri(); ?>/images/payment.png">
		   </div>
        <div class="copy_right wrap">
        <p>We take the theft of our original work very seriously and would draw to your attention it is protected under UK copyright law.
Please note we always sue for compensation if any part of our website, design or SEO whether text or images, are found being used.
All logos & trademarks shown are in respective of their owners.</p>
		
		   </div>

		    <div class="copy_right wrap">
				<p>Partsformobile © All rights Reseverd</p>
		   </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"><span id="toTopHover"> </span></a>

<?php wp_footer(); ?>

<!--Language Conversion-->
<script type="text/javascript">
 window.onload = function() {
  $.getJSON("http://freegeoip.net/json/", function (data) {
   var language= '';
      var country_code = data.country_code;

      switch(country_code){
       case ("ES" || "ESP"):
        language = 'es';

       case ("DE" || "DEU"):
        language = 'de';

       case ("FR" || "FRA"):
        language = 'fr';

       case ("PT" || "PRT"):
        language = 'pt';

       case ("DK" || "DNK"):
        language = 'da';

       case ("NL" || "NLD"):
        language = 'nl';

       case ("CZ" || "CZE"):
        language = 'cs';

       case ("GR" || "GRC"):
        language = 'el';

       case ("PL" || "POL"):
        language = 'pl';

       case ("SE" || "SWE"):
        language = 'el';

       default:
        language = 'en';
      }
      
      PrisnaGWT.translate(language); return false;    
  });
 };
</script>
</body>
</html>