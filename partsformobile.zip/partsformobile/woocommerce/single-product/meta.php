<?php
/**
 * Single Product Meta
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/meta.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woothemes.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $post, $product;

$cat_count = sizeof( get_the_terms( $post->ID, 'product_cat' ) );
$tag_count = sizeof( get_the_terms( $post->ID, 'product_tag' ) );

?>

<div class="single_details">Details</div>

<div class="price-number_single">
							

	<?php do_action( 'woocommerce_product_meta_start' ); ?>

	<?php if ( wc_product_sku_enabled() && ( $product->get_sku() || $product->is_type( 'variable' ) ) ) : ?>
		
		<div class="descrioption"><?php the_content(); ?></div>
		<div class="other_details">
		<p>
		<span class="one_left"><?php _e( 'SKU:', 'woocommerce' ); ?></span> 
		<span class="one_right"><?php echo ( $sku = $product->get_sku() ) ? $sku : __( 'N/A', 'woocommerce' ); ?></span>
		</p>
		<p>
		<!-- <span class="one_left">Weight: </span>
		<span class="one_right"><?php //echo apply_filters( 'woocommerce_cart_item_weight', $product->get_weight());?> g</span>
		 --></p>
		</div>
	<?php endif; ?>
		<p>
		<span class="rupees">
		
		<p><span class="one_left">Price: </span><span class="one_right red"><?php echo woocommerce_price($product->get_price_including_tax()); ?></span> inc. VAT</p>
		</span>
		</p>
						



	<?php //echo $product->get_categories( ', ', '<span class="posted_in">' . _n( 'Category:', 'Categories:', $cat_count, 'woocommerce' ) . ' ', '</span>' ); ?>

	<?php //echo $product->get_tags( ', ', '<span class="tagged_as">' . _n( 'Tag:', 'Tags:', $tag_count, 'woocommerce' ) . ' ', '</span>' ); ?>

	<?php do_action( 'woocommerce_product_meta_end' ); ?>

</div>

