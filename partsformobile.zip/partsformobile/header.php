<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico" type="image/x-icon" />
<link href="<?php echo get_template_directory_uri(); ?>/css/slider.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/move-top.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/easing.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/startstop-slider.js"></script>
<script src="https://use.fontawesome.com/175e6a9e9d.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_uri(); ?>" />

<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
  <div class="wrap">
	<div class="header">
		<div class="header_top">
			<div class="logo">
				<a href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.png"  width="160px" alt="Logo" /></a>
			</div>
			  
			<div class="call">
			 <p>
			 <span class="tel">TEL :</span> <span class="number">0844 579 6296(STRICTLY TRADE ONLY)</span>
			 </p>
			<?php echo do_shortcode('[prisna-google-website-translator]'); ?>
			</div>
			
			
	     	<div class="clear"></div>
		</div>
	<div class="header_bottom">
	     	<div class="menu">
		            
		            <?php
                        wp_nav_menu( array(
                            'theme_location' => 'main-menu',
                            'menu_class'     => 'menu'
                            
                         ) );
                    ?>
                               
	     	</div>
	     	
	     	<div class="clear"></div>
	</div>	     
</div>