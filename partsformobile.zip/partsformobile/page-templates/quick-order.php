
<?php
/**
* Template Name: Order Page Template
*/
 get_header(); ?>

<div class="location">
<font class="bread-crumb last-bread-crumb">Parts4mobile Limited</font>
</div>
 		



<tr>
<th >Thumbnail</th>
<th ><?php echo('Model'); ?></th>
<th ><?php echo('Price'); ?></th>
<th ><?php echo('Quantity'); ?></th>
<th ><?php echo('Cosmetics'); ?></th>
<th ><?php echo('Description'); ?> </th>
<th ><?php echo('Item#'); ?></th>
<th > </th>
<th > </th>
<th > </th>
</tr>
</thead>

<tbody>	<?php while ( have_posts() ) : the_post(); ?>

<tr>
<td ><h3><?php	do_action( 'woocommerce_before_shop_loop_item_title' );?></td>
<td> <a>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></td>

<td><?php	do_action( 'woocommerce_after_shop_loop_item_title' );?></td>
<td class="product-quantity">
<?php
$product_quantity = sprintf( '<div class="quantity"><input name="cart[%s][qty]" data-min="%s" data-max="%s" value="0" size="4" title="Qty" class="input-text qty text" maxlength="12" /></div>', $cart_item_key, $data_min, $data_max, esc_attr( $values['quantity'] ) );
echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key );
?>
</td>
<!-- Description -->
<td> <?php if ( $woo_options[ 'woo_post_content' ] == "content" ) the_content(__( 'Read More...', 'woothemes' )); else the_excerpt(); ?> </td>
<!-- End of Description -->

<!-- Top Description -->
<td> <?php the_content(); ?> </td>
<!-- End of Top Description -->

<td> <?php echo('Item#'); ?> </td>

<!-- Add here the Add to Cart Button -->
<td colspan="6"><?php do_action( 'woocommerce_after_shop_loop_item' ); ?></td>
<!-- End of CART -->

</tr></a>

<?php endwhile; ?>
<?php get_footer(); ?>