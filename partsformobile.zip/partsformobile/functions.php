<?php

add_filter( 'widget_text', 'shortcode_unautop');
add_filter( 'widget_text', 'do_shortcode');

add_action( 'after_setup_theme', 'blankslate_setup' );
function blankslate_setup()
{
load_theme_textdomain( 'blankslate', get_template_directory() . '/languages' );
add_theme_support( 'title-tag' );
add_theme_support( 'automatic-feed-links' );
add_theme_support( 'post-thumbnails' );
global $content_width;
if ( ! isset( $content_width ) ) $content_width = 640;
register_nav_menus(
array( 'main-menu' => __( 'Main Menu', 'blankslate' ) )
);
}
add_action( 'wp_enqueue_scripts', 'blankslate_load_scripts' );
function blankslate_load_scripts()
{
wp_enqueue_script( 'jquery' );
}
add_action( 'comment_form_before', 'blankslate_enqueue_comment_reply_script' );
function blankslate_enqueue_comment_reply_script()
{
if ( get_option( 'thread_comments' ) ) { wp_enqueue_script( 'comment-reply' ); }
}
add_filter( 'the_title', 'blankslate_title' );
function blankslate_title( $title ) {
if ( $title == '' ) {
return '&rarr;';
} else {
return $title;
}
}
add_filter( 'wp_title', 'blankslate_filter_wp_title' );
function blankslate_filter_wp_title( $title )
{
return $title . esc_attr( get_bloginfo( 'name' ) );
}




remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );



add_action( 'widgets_init', 'blankslate_widgets_init' );

function blankslate_widgets_init()
{

register_sidebar( array (
	'name' => __( 'Sidebar Left Widget Area', 'blankslate' ),
	'id' => 'sidebar-left-widget-area',
	'before_widget' => '<div class="header_bottom_left categories">',
	'after_widget' => "</div>",
	'before_title' => '<h3>',
	'after_title' => '</h3>',
) );

register_sidebar( array (
	'name' => __( 'Sidebar Right Widget Area', 'blankslate' ),
	'id' => 'sidebar-right-widget-area',
	'before_widget' => '<div class="header_bottom_right">',
	'after_widget' => "</div>",
	'before_title' => '<h3>',
	'after_title' => '</h3>',
) );

register_sidebar(array(
    'name' => __('Footer First Widget', 'blankslate'),
    'id' => 'footer-one-widget-area',
    'before_widget' => '<div class="col_1_of_4 span_1_of_4">',
    'after_widget' => "</div>",
    'before_title' => '<h4>',
    'after_title' => '</h4>'
));

register_sidebar(array(
    'name' => __('Footer Second Widget', 'blankslate'),
    'id' => 'footer-two-widget-area',
    'before_widget' => '<div class="col_1_of_4 span_1_of_4">',
    'after_widget' => "</div>",
    'before_title' => '<h4>',
    'after_title' => '</h4>'
));

register_sidebar(array(
    'name' => __('Footer Third Widget', 'blankslate'),
    'id' => 'footer-three-widget-area',
    'before_widget' => '<div class="col_1_of_4 span_1_of_4">',
    'after_widget' => "</div>",
    'before_title' => '<h4>',
    'after_title' => '</h4>'
));


register_sidebar(array(
    'name' => __('Footer Fourth Widget', 'blankslate'),
    'id' => 'footer-four-widget-area',
    'before_widget' => '<div class="col_1_of_4 span_1_of_4">',
    'after_widget' => "</div>",
    'before_title' => '<h4>',
    'after_title' => '</h4>'
));

}


/*For Execute Php on Widget*/

add_filter('widget_text','execute_php',100);
function execute_php($html){
     if(strpos($html,"<"."?php")!==false){
          ob_start();
          eval("?".">".$html);
          $html=ob_get_contents();
          ob_end_clean();
     }
     return $html;
}












remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 40 );

remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 30 );




function blankslate_custom_pings( $comment )
{
$GLOBALS['comment'] = $comment;
?>
<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>"><?php echo comment_author_link(); ?></li>
<?php 
}
add_filter( 'get_comments_number', 'blankslate_comments_number' );
function blankslate_comments_number( $count )
{
if ( !is_admin() ) {
global $id;
$comments_by_type = &separate_comments( get_comments( 'status=approve&post_id=' . $id ) );
return count( $comments_by_type['comment'] );
} else {
return $count;
}
}



