<?php
/**
 * Template Name: Blog Page Template
 */
get_header(); ?>

<div class="category">
<div id="top-banner">
<div class="topcontent">
<h1><?php echo the_title(); ?></h1>
</div>
</div>
<section class="filter">
<div class="wrapper wrap">
<div class="taxonomy-filter">
<p>Select a category:</p>

<li id="categories">
	<form id="category-select" class="category-select" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">

		<?php
		$args = array(
			'show_option_none' => __( 'Select category' ),
			'show_count'       => 1,
			'orderby'          => 'name',
			'echo'             => 0,
		);
		?>

		<?php $select  = wp_dropdown_categories( $args ); ?>
		<?php $replace = "<select$1 onchange='return this.form.submit()'>"; ?>
		<?php $select  = preg_replace( '#<select([^>]*)>#', $replace, $select ); ?>

		<?php echo $select; ?>

		<noscript>
			<input type="submit" value="View" />
		</noscript>

	</form>
</li>

 </div>
<div class="searchform-wrapper">
<form role="search" method="get" class="search-form" action="<?php bloginfo('home'); ?>/">
<label>
<span class="screen-reader-text">Search the blog</span>
</label>
<input type="search" class="search-field" placeholder="Search the blog..." value="" name="s" title="Search for:"/>
<input type="submit" class="search-submit button" value="go"/>
</form>
</div>
</div>
</section>
<section class="post-list">
<div class="wrapper wrap">
<div id="primary" class="content-area wrap">
<main id="main" class="site-main" role="main">

<?php query_posts('post_type=post&post_status=publish&order=ASC&paged='. get_query_var('paged')); ?>
<?php if ( have_posts() ) : ?>

<p class="msg success"><i class="icon-th"></i> <strong><?php echo $wp_query->found_posts; ?></strong> posts found.</p>
<div class="navigation-links">
<?php 
the_posts_pagination(array(
'show_all'=>true,
'prev_text'=>'PREV',
'next_text'=>'NEXT',
'screen_reader_text'=>' ',
'before_page_number'=>'<b>',
'after_page_number'=>'</b>'
)); 
?>
</div>

<div class="row">
<?php while(have_posts()) : the_post();  ?>
<div class="col post-list-item ">
<a href="<?php the_permalink();?>" title="<?php the_title(); ?>">
<?php the_post_thumbnail($max_width); ?>
<p class="post-title"><?php the_title(); ?></p>
</a>
<p class="post-excerpt">
<?php read_more(50); ?></p>
<div class="author-deets">
<div class="author-image">
<a href="#">
<?php echo get_avatar( get_the_author_email()); ?>
</a>
</div>
<div class="post-meta">
<p class="archive-date">Written by <a href="#"><?php the_author();?></a></p>
<p class="archive-date"><?php the_time('F,d,Y'); ?></p>
</div>
</div>
</div>
<?php endwhile ; ?>
</div>
<?php endif; wp_reset_query(); ?>
</main>
 
</div>
</div>
 
</section>
</div>
<?php get_footer();?>

