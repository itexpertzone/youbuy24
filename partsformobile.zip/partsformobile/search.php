<?php get_header(); ?>
	
<div class="location">
<font class="bread-crumb last-bread-crumb">Parts4mobile Limited</font>
</div>

	<div class="side_left">
	<?php dynamic_sidebar( 'sidebar-left-widget-area' ); ?>
	</div>



 			<div class="main">
 				<div class="header_slide">
						 
		   <div class="clear"></div>
		</div>
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3><?php printf( __( 'Search Results for: %s', 'blankslate' ), get_search_query() ); ?></h3>
    		</div>
    		<div class="clear"></div>
    	</div>
	      <div class="section group">

	     <?php while ( have_posts() ) : the_post(); ?>

				<div class="grid_1_of_4 images_1_of_4">
					 <h2><?php the_title(); ?></h2>
					 <a id="id-<?php the_id(); ?>" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
					 <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="<?php the_title(); ?>"/>'; ?>
					 </a>
					 <div class="price-details">
				       <div class="price-number">
							<div class="rupees">
<p>Price: <span class="no_tax">€<?php echo $product->price/1.2; ?></span> ex. VAT</p>
<p>Price: <span><?php echo woocommerce_price($product->get_price()); ?></span> in. VAT</p>

							</div>
							<div class="quantity">
							<span class="quantity-title">Quantity</span>
							</div>
							</div>
					    
					    <div class="add-cart">								
						  <h4><?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?></h4>
					    </div>
					
					    <div class="clear"></div>
					</div>
					 
				</div>

				<?php endwhile; ?>

        		<?php wp_reset_query(); ?>
				
			</div>
    	</div>
 	</div>

	<div class="side_right">
	<?php dynamic_sidebar( 'sidebar-right-widget-area' ); ?>
	</div>


</div>

<?php get_footer(); ?>