<?php
/**
* Template Name: Home Page Template
*/
 get_header(); ?>

<div class="location">
<font class="bread-crumb last-bread-crumb">Parts4mobile Limited</font>
</div>
 			

	<div class="side_left">
	<?php dynamic_sidebar( 'sidebar-left-widget-area' ); ?>
	</div>



 			<div class="main">
 				<div class="header_slide">
						 <div class="slider">					     
							 <div id="slider">
			                   <img src="<?php echo get_template_directory_uri(); ?>/images/top_banner.jpg">      	
				        	</div>
					 <div class="clear"></div>					       
		         </div>
		   <div class="clear"></div>
		</div>
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>Featured Products</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
	      <div class="section group">

	    <?php  $args = array( 'post_type' => 'product','posts_per_page' => 90, 'orderby' =>'date','order' => 'DESC' );
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>

				<div class="grid_1_of_4 images_1_of_4">
					 <h2><?php the_title(); ?></h2>
					 <a id="id-<?php the_id(); ?>" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
					 <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="<?php the_title(); ?>"/>'; ?>
					 </a>
					 <div class="price-details">
				       <div class="price-number">


							<div class="rupees">
							
							<p>Price: <span><?php echo woocommerce_price($product->get_price_including_tax()); ?></span> in. VAT</p>
							</div>
							<div class="quantity">
							<span class="quantity-title">Quantity</span>
							</div>
							</div>
					    
					    <div class="add-cart">								
						  <h4><?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?></h4>
					    </div>
					
					    <div class="clear"></div>
					</div>
					 
				</div>

				<?php endwhile; ?>
        		<?php wp_reset_query(); ?>
				
			</div>
    	</div>
 	</div>


	<div class="side_right">
	<?php dynamic_sidebar( 'sidebar-right-widget-area' ); ?>
	</div>


</div>

<?php get_footer(); ?>