<?php get_header(); ?>

<div class="location">
	<font class="bread-crumb last-bread-crumb">Parts4mobile Limited</font>
</div>


	<div class="side_left">
	<?php dynamic_sidebar( 'sidebar-left-widget-area' ); ?>
	</div>


<div class="main indivi_page">
	<div class="content">
		<div class="content_top">
			<div class="heading">
				<h3><?php the_title(); ?></h3>
			</div>
			<div class="clear"></div>
		</div>
		<div class="section group">

			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<section class="entry-content">
						<?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } ?>
						<?php the_content(); ?>
						<div class="entry-links"><?php wp_link_pages(); ?></div>
					</section>
				</article>
				<?php if ( ! post_password_required() ) comments_template( '', true ); ?>
			<?php endwhile; endif; ?>
		</section>

		</div>
	</div>
</div>


	<div class="side_right">
	<?php dynamic_sidebar( 'sidebar-right-widget-area' ); ?>
	</div>


</div>

<?php get_footer(); ?>